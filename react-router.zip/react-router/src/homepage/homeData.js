const homeData = [
    {
        id: 1,
        title: "Counter",
        path: "/counter",
    },
    {
        id: 2,
        title: "Accordion",
        path: "/accordion",
    },

    {
        id: 3,
        title: "Tabs",
        path: "/tabs",
    },

    {
        id: 4,
        title: "Sidebar",
        path: "/sidebar",
    },

    {
        id: 5,
        title: "Sticky Header",
        path: "/sticky-header",
    },
    {
        id: 6,
        title: "Back To Top",
        path: "/back-top",
    },

    {
        id: 7,
        title: "Read More",
        path: "/read-more",
    },

    {
        id: 8,
        title: "Modal",
        path: "/modal",
    },
    {
        id: 9,
        title: "Open Clicked Modal",
        path: "/clicked-modal",
    },
    {
        id: 10,
        title: "Load More",
        path: "/load-more",
    },
    {
        id: 11,
        title: "Filterable Gallery",
        path: "/filterable-gallery",
    },
    {
        id: 12,
        title: "Search Filter",
        path: "/search-filter",
    },
];

export default homeData;
