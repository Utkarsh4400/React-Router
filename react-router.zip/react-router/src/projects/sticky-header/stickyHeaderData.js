const stickyHeaderData = [
    {
        id: 1,
        title: "Home",
        path: "/"
    },
    {
        id: 2,
        title: "About",
        path: "/"
    },
    {
        id: 3,
        title: "Services",
        path: "/"
    },
    {
        id: 4,
        title: "Contact",
        path: "/"
    }
];

export default stickyHeaderData;